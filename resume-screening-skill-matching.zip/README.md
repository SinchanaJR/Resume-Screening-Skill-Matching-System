# Resume Screening & Skill Matching API

A runnable Python + FastAPI project that compares resume text with a job description, extracts known skills, and returns a transparent match score with matched and missing skills.

## Requirements
- Python 3.10 or newer

## Run locally
Windows:
```powershell
py -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
uvicorn app:app --reload
```
macOS/Linux:
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app:app --reload
```
Open `http://127.0.0.1:8000/docs` for interactive API testing.

## Endpoints
- `GET /health`
- `GET /skills`
- `POST /analyze`

## Example JSON for POST /analyze
```json
{
  "resume_text": "Python developer with SQL, Pandas and data analysis experience",
  "job_description": "Looking for Python, SQL, machine learning and communication skills"
}
```

## Responsible use
This is a demo keyword matcher, not an automated hiring decision system. It does not parse PDF/DOCX files or use semantic AI. Never upload real candidates' private data without authorization.
