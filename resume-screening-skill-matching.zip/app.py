from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
import re

app = FastAPI(
    title="Resume Screening & Skill Matching API",
    description="Demo REST API for transparent resume-to-job skill matching.",
    version="1.0.0",
)

SKILLS = [
    "python", "java", "go", "sql", "mysql", "postgresql", "html", "css",
    "javascript", "machine learning", "deep learning", "data analysis",
    "pandas", "numpy", "streamlit", "fastapi", "rest api", "git",
    "docker", "communication", "problem solving", "linux", "aws"
]

class AnalyzeRequest(BaseModel):
    resume_text: str = Field(min_length=1, max_length=50000)
    job_description: str = Field(min_length=1, max_length=50000)

def detect_skills(text: str) -> list[str]:
    lowered = text.lower()
    found = []
    for skill in SKILLS:
        pattern = r"(?<![a-z0-9])" + re.escape(skill) + r"(?![a-z0-9])"
        if re.search(pattern, lowered):
            found.append(skill)
    return found

@app.get("/health")
def health():
    return {"status": "ok"}

@app.get("/skills")
def list_skills():
    return {"skills_supported": SKILLS, "count": len(SKILLS)}

@app.post("/analyze")
def analyze(request: AnalyzeRequest):
    resume_skills = set(detect_skills(request.resume_text))
    job_skills = set(detect_skills(request.job_description))

    if not job_skills:
        raise HTTPException(
            status_code=422,
            detail="No supported skills were detected in the job description."
        )

    matched = sorted(resume_skills & job_skills)
    missing = sorted(job_skills - resume_skills)
    score = round((len(matched) / len(job_skills)) * 100)

    return {
        "match_score_percent": score,
        "job_skills_detected": sorted(job_skills),
        "resume_skills_detected": sorted(resume_skills),
        "matched_skills": matched,
        "missing_skills": missing,
        "explanation": (
            f"{len(matched)} of {len(job_skills)} detected job skills "
            f"also appear in the resume text."
        ),
        "method": "case-insensitive keyword matching"
    }
